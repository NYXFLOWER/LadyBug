package final_project;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

public class swingCalendar extends JFrame implements ActionListener {
    public static swingCalendar u1;
    private JTextField jTextField;
    private JTextArea jTextArea;
    private JButton[] jButton;
    private JMenuItem[] jMenuItems;
    private JMenu[] jMenus;
    private JMenuBar mbar;
    private JComboBox comboBox;
    private JLabel jLabel;
    public swingCalendar(){
        super("����");
        jButton = new JButton[1];
        jMenus = new JMenu[3];
        jButton = new JButton[1];
        comboBox = new JComboBox<String>();
        jLabel = new JLabel();
        jTextField = new JTextField();
        jTextArea = new JTextArea();
        jMenuItems = new JMenuItem[4];

        jMenuItems[0] = new JMenuItem("������");
        jMenuItems[1] = new JMenuItem("�����ĵ�");
        jMenuItems[2] = new JMenuItem("�˳�");
        jMenuItems[3] = new JMenuItem("����");
        jMenuItems[0].addActionListener(this);
        jMenuItems[1].addActionListener(this);
        jMenuItems[2].addActionListener(this);
        jMenuItems[3].addActionListener(this);


        jMenus[0] = new JMenu("�鿴(V)");
        jMenus[1] = new JMenu("�༭(E)");
        jMenus[2] = new JMenu("����(H)");
        for (int i = 0 ; i < jMenus.length;i++){
            jMenus[i].addActionListener(this);
        }
        jMenus[2].add(jMenuItems[0]);
        jMenus[2].add(jMenuItems[1]);
        jMenus[2].add(jMenuItems[2]);
        jMenus[1].add(jMenuItems[3]);

        comboBox.addItem("һ��");
        comboBox.addItem("����");
        comboBox.addItem("����");
        comboBox.addItem("����");
        comboBox.addItem("����");
        comboBox.addItem("����");
        comboBox.addItem("����");
        comboBox.addItem("����");
        comboBox.addItem("����");
        comboBox.addItem("ʮ��");
        comboBox.addItem("ʮһ��");
        comboBox.addItem("ʮ����");
        comboBox.addActionListener(this);
        comboBox.setBounds(100,20,70,30);

        jButton[0] = new JButton("ȷ��");
        jButton[0].setBounds(350,20,70,30);
        jButton[0].setForeground(Color.blue);
        jButton[0].setFont(new Font("����",Font.PLAIN,14));
        jButton[0].addActionListener(this);

        jTextField= new JTextField("",40);
        jTextField.setFont(new Font("����",Font.PLAIN,11));
        jTextField.setForeground(Color.black);
        jTextField.setBounds(10,20,50,30);
        jTextField.setHorizontalAlignment(JTextField.RIGHT);
        jTextField.addActionListener(this);
        jTextField.setEditable(true);

        mbar = new JMenuBar();
        mbar.add(jMenus[0]);
        mbar.add(jMenus[1]);
        mbar.add(jMenus[2]);
        this.setJMenuBar(mbar);

        jTextArea = new JTextArea();
        jTextArea.setFont(new Font("����",Font.BOLD,14));
        jTextArea.setForeground(Color.black);
        jTextArea.setBounds(50,110,400,300);
        jTextArea.setEditable(false);


        jLabel.setBounds(230,20,50,30);
        jLabel.setText("");
        jLabel.setForeground(Color.red);


        Container winContainer = this.getContentPane();
        winContainer.setLayout(null);
        winContainer.add(jTextField);
        winContainer.add(jTextArea);
        winContainer.add(jButton[0]);
        winContainer.add(comboBox);
        winContainer.add(jTextArea);
        winContainer.add(jLabel);
        this.setTitle("����");
        this.setLocation(300, 300);
        this.setSize(500,500);
        this.setVisible(true);

    }

    public static void main(String[] args) {
        u1 = new swingCalendar();
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==jButton[0]) {
            jLabel.setText("");
            jTextArea.setText("");
            String aa = jTextField.getText();
            if (aa.charAt(0)<'0'||aa.charAt(0)>'9'){
                JOptionPane.showMessageDialog(u1, "�޷���ȡ�������,����������", "��ʾ��Ϣ", 1);
                comboBox.setSelectedIndex(0);
                jTextField.setText("");
            }
            else{
                int year = Integer.valueOf(aa);
                if (year <= 250) {
                    JOptionPane.showMessageDialog(u1, "�Բ���,�������޷���ѯ��"+year+"�������\n\t�����˵���-����-��ϵ����ʦ", "��ʾ��Ϣ", 1);
                    comboBox.setSelectedIndex(0);
                    jTextField.setText("");
                }
                else {
                    jLabel.setText(aa);


                    String[] English = {"һ", "��", "��", "��", "��", "��", "��"};
                    String[] Month = {"һ��", "����", "����", "����", "����", "����", "����", "����", "����", "ʮ��", "ʮһ��", "ʮ����",};
                    Calendar calendar = Calendar.getInstance();
                    StringBuffer stringBuffer = new StringBuffer("");
                    for (int j = 0; j < English.length; j++) {
                        stringBuffer.append(English[j] + "\t");
                    }
                    stringBuffer.append("\n");
                    int index = comboBox.getSelectedIndex();
                    calendar.clear();
                    calendar.set(Calendar.YEAR, year);

                    switch (index) {
                        case 0: {
                            calendar.set(Calendar.MONTH, index);
                            int Month_Days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                            int First_Day = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                            int n = 0;
                            if (First_Day > 0) {
                                for (int k = 2; k <= First_Day; k++) {
                                    n = First_Day - 1;
                                    stringBuffer.append("\t");
                                }
                            }
                            if (First_Day == 0) {
                                n = 6;
                                for (int k = 1; k < 7; k++) {
                                    stringBuffer.append("\t");
                                }
                            }
                            for (int k = 1; k <= Month_Days; k++) {
                                stringBuffer.append(k + "\t");
                                n++;
                                if (n % 7 == 0) {
                                    stringBuffer.append("\n");
                                }

                            }
                            break;
                        }
                        case 1: {
                            calendar.set(Calendar.MONTH, index);
                            int Month_Days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                            int First_Day = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                            int n = 0;
                            if (First_Day > 0) {
                                for (int k = 2; k <= First_Day; k++) {
                                    n = First_Day - 1;
                                    stringBuffer.append("\t");
                                }
                            }
                            if (First_Day == 0) {
                                n = 6;
                                for (int k = 1; k < 7; k++) {
                                    stringBuffer.append("\t");
                                }
                            }
                            for (int k = 1; k <= Month_Days; k++) {
                                stringBuffer.append(k + "\t");
                                n++;
                                if (n % 7 == 0) {
                                    stringBuffer.append("\n");
                                }

                            }

                            break;
                        }
                        case 2: {
                            calendar.set(Calendar.MONTH, index);
                            int Month_Days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                            int First_Day = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                            int n = 0;
                            if (First_Day > 0) {
                                for (int k = 2; k <= First_Day; k++) {
                                    n = First_Day - 1;
                                    stringBuffer.append("\t");
                                }
                            }
                            if (First_Day == 0) {
                                n = 6;
                                for (int k = 1; k < 7; k++) {
                                    stringBuffer.append("\t");
                                }
                            }
                            for (int k = 1; k <= Month_Days; k++) {
                                stringBuffer.append(k + "\t");
                                n++;
                                if (n % 7 == 0) {
                                    stringBuffer.append("\n");
                                }

                            }
                            break;
                        }
                        case 3: {
                            calendar.set(Calendar.MONTH, index);
                            int Month_Days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                            int First_Day = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                            int n = 0;
                            if (First_Day > 0) {
                                for (int k = 2; k <= First_Day; k++) {
                                    n = First_Day - 1;
                                    stringBuffer.append("\t");
                                }
                            }
                            if (First_Day == 0) {
                                n = 6;
                                for (int k = 1; k < 7; k++) {
                                    stringBuffer.append("\t");
                                }
                            }
                            for (int k = 1; k <= Month_Days; k++) {
                                stringBuffer.append(k + "\t");
                                n++;
                                if (n % 7 == 0) {
                                    stringBuffer.append("\n");
                                }

                            }
                            break;
                        }
                        case 4: {
                            calendar.set(Calendar.MONTH, index);
                            int Month_Days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                            int First_Day = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                            int n = 0;
                            if (First_Day > 0) {
                                for (int k = 2; k <= First_Day; k++) {
                                    n = First_Day - 1;
                                    stringBuffer.append("\t");
                                }
                            }
                            if (First_Day == 0) {
                                n = 6;
                                for (int k = 1; k < 7; k++) {
                                    stringBuffer.append("\t");
                                }
                            }
                            for (int k = 1; k <= Month_Days; k++) {
                                stringBuffer.append(k + "\t");
                                n++;
                                if (n % 7 == 0) {
                                    stringBuffer.append("\n");
                                }

                            }
                            break;
                        }
                        case 5: {
                            calendar.set(Calendar.MONTH, index);
                            int Month_Days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                            int First_Day = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                            int n = 0;
                            if (First_Day > 0) {
                                for (int k = 2; k <= First_Day; k++) {
                                    n = First_Day - 1;
                                    stringBuffer.append("\t");
                                }
                            }
                            if (First_Day == 0) {
                                n = 6;
                                for (int k = 1; k < 7; k++) {
                                    stringBuffer.append("\t");
                                }
                            }
                            for (int k = 1; k <= Month_Days; k++) {
                                stringBuffer.append(k + "\t");
                                n++;
                                if (n % 7 == 0) {
                                    stringBuffer.append("\n");
                                }

                            }
                            break;
                        }
                        case 6: {
                            calendar.set(Calendar.MONTH, index);
                            int Month_Days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                            int First_Day = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                            int n = 0;
                            if (First_Day > 0) {
                                for (int k = 2; k <= First_Day; k++) {
                                    n = First_Day - 1;
                                    stringBuffer.append("\t");
                                }
                            }
                            if (First_Day == 0) {
                                n = 6;
                                for (int k = 1; k < 7; k++) {
                                    stringBuffer.append("\t");
                                }
                            }
                            for (int k = 1; k <= Month_Days; k++) {
                                stringBuffer.append(k + "\t");
                                n++;
                                if (n % 7 == 0) {
                                    stringBuffer.append("\n");
                                }

                            }
                            break;
                        }
                        case 7: {
                            calendar.set(Calendar.MONTH, index);
                            int Month_Days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                            int First_Day = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                            int n = 0;
                            if (First_Day > 0) {
                                for (int k = 2; k <= First_Day; k++) {
                                    n = First_Day - 1;
                                    stringBuffer.append("\t");
                                }
                            }
                            if (First_Day == 0) {
                                n = 6;
                                for (int k = 1; k < 7; k++) {
                                    stringBuffer.append("\t");
                                }
                            }
                            for (int k = 1; k <= Month_Days; k++) {
                                stringBuffer.append(k + "\t");
                                n++;
                                if (n % 7 == 0) {
                                    stringBuffer.append("\n");
                                }

                            }
                            break;
                        }
                        case 8: {
                            calendar.set(Calendar.MONTH, index);
                            int Month_Days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                            int First_Day = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                            int n = 0;
                            if (First_Day > 0) {
                                for (int k = 2; k <= First_Day; k++) {
                                    n = First_Day - 1;
                                    stringBuffer.append("\t");
                                }
                            }
                            if (First_Day == 0) {
                                n = 6;
                                for (int k = 1; k < 7; k++) {
                                    stringBuffer.append("\t");
                                }
                            }
                            for (int k = 1; k <= Month_Days; k++) {
                                stringBuffer.append(k + "\t");
                                n++;
                                if (n % 7 == 0) {
                                    stringBuffer.append("\n");
                                }

                            }
                            break;
                        }
                        case 9: {
                            calendar.set(Calendar.MONTH, index);
                            int Month_Days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                            int First_Day = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                            int n = 0;
                            if (First_Day > 0) {
                                for (int k = 2; k <= First_Day; k++) {
                                    n = First_Day - 1;
                                    stringBuffer.append("\t");
                                }
                            }
                            if (First_Day == 0) {
                                n = 6;
                                for (int k = 1; k < 7; k++) {
                                    stringBuffer.append("\t");
                                }
                            }
                            for (int k = 1; k <= Month_Days; k++) {
                                stringBuffer.append(k + "\t");
                                n++;
                                if (n % 7 == 0) {
                                    stringBuffer.append("\n");
                                }

                            }
                            break;
                        }
                        case 10: {
                            calendar.set(Calendar.MONTH, index);
                            int Month_Days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                            int First_Day = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                            int n = 0;
                            if (First_Day > 0) {
                                for (int k = 2; k <= First_Day; k++) {
                                    n = First_Day - 1;
                                    stringBuffer.append("\t");
                                }
                            }
                            if (First_Day == 0) {
                                n = 6;
                                for (int k = 1; k < 7; k++) {
                                    stringBuffer.append("\t");
                                }
                            }
                            for (int k = 1; k <= Month_Days; k++) {
                                stringBuffer.append(k + "\t");
                                n++;
                                if (n % 7 == 0) {
                                    stringBuffer.append("\n");
                                }

                            }
                            break;
                        }
                        case 11: {
                            calendar.set(Calendar.MONTH, index);
                            int Month_Days = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
                            int First_Day = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                            int n = 0;
                            if (First_Day > 0) {
                                for (int k = 2; k <= First_Day; k++) {
                                    n = First_Day - 1;
                                    stringBuffer.append("\t");
                                }
                            }
                            if (First_Day == 0) {
                                n = 6;
                                for (int k = 1; k < 7; k++) {
                                    stringBuffer.append("\t");
                                }
                            }
                            for (int k = 1; k <= Month_Days; k++) {
                                stringBuffer.append(k + "\t");
                                n++;
                                if (n % 7 == 0) {
                                    stringBuffer.append("\n");
                                }

                            }
                            break;
                        }


                    }

                    jTextArea.setText(String.valueOf(stringBuffer));


                }
            }

        }
        else if (e.getSource()==jMenuItems[0]){
            JOptionPane.showMessageDialog(u1,"������WHXJT","��������Ϣ",1);

        }
        else if (e.getSource()==jMenuItems[1]){
            JOptionPane.showMessageDialog(u1,"��ʱû�п����ĵ�","�����ĵ�",1);
        }
        else if (e.getSource()==jMenuItems[2]){
            int aa = JOptionPane.showConfirmDialog(u1,"��ȷ��Ҫ�˳���","�˳�",1);
            if(aa==0) {
                System.exit(0);
            }

        }
        else if(e.getSource()==jMenuItems[3]){
            jLabel.setText("");
            jTextArea.setText("");
            jTextField.setText("");
            comboBox.setSelectedIndex(0);
            JOptionPane.showMessageDialog(u1,"��ճɹ�","���",1);
        }

        }




    }
