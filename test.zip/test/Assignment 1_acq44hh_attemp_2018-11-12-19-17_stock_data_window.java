package final_project;

import java.awt.Dimension;
import java.net.URL;
import java.util.Date;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

public class stock_data_window{
	public stock_data_window(String stock_name,Date start_date,Date end_date) {
		JFrame f=new JFrame();
		JEditorPane show=new JEditorPane();
		JScrollPane ScrollPane = new JScrollPane(show);
		ScrollPane.setPreferredSize(new Dimension(300, 500)); 
		String read_in_line;
		
		String website="http://quotes.wsj.com/"+stock_name+"/historical-prices/download?MOD_VIEW=page&num_rows=300&startDate="+start_date_time+"&endDate="+end_date_time;
    	URL u=new URL(website);
    	show.setPage(u);
    	
    	String read_data=show.getText();
    	String read_stock_data[]=read_data.split("\n");
    	for(int i=1;i<read_stock_data.length;i++) {
    		if(read_stock_data[1]==null) {
    			JOptionPane.showMessageDialog(null,"The date you select do not have any data, please check it", "Error!", JOptionPane.ERROR_MESSAGE);
    			break;
    		}
    		else {
    			read_in_line=read_stock_data[i].split(",");
    			//for(int j=0;j)
    		}
    		
    	
    	
    }
	
	
		
	}
}
