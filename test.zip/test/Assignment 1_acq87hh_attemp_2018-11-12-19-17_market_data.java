package final_project;

import javax.swing.*;

public class market_data extends JFrame{
	public static void main(String a) {
		JFrame f=new market_data();//create a frame using this class
		
	}
}
